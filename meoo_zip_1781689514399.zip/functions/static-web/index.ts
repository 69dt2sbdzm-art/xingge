import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const HTML_CONTENT = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,viewport-fit=cover">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <title>谁是卧底英语版</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 100%);
      min-height: 100vh;
      color: #fff;
    }
    .page { min-height: 100vh; padding: 20px; display: flex; flex-direction: column; }
    .header { text-align: center; padding: 20px 0; }
    .header h1 {
      font-size: 28px;
      background: linear-gradient(90deg, #22d3ee, #e879f9);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .card {
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(34, 211, 238, 0.3);
      border-radius: 16px;
      padding: 24px;
      margin-bottom: 16px;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 16px;
      margin-bottom: 12px;
      border-radius: 12px;
      border: none;
      font-weight: bold;
      font-size: 16px;
      cursor: pointer;
      text-align: center;
    }
    .btn-primary {
      background: linear-gradient(135deg, #22d3ee 0%, #0891b2 100%);
      color: #000;
    }
    .word-display { text-align: center; padding: 40px 20px; }
    .word-display h2 { font-size: 36px; color: #22d3ee; margin-bottom: 20px; }
    .player-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px;
      background: rgba(255,255,255,0.03);
      border-radius: 8px;
      margin-bottom: 8px;
    }
    .hidden { display: none !important; }
    .room-code {
      text-align: center;
      font-size: 32px;
      color: #22d3ee;
      letter-spacing: 8px;
      margin: 20px 0;
    }
  </style>
</head>
<body>
  <div id="app">
    <div id="home-page" class="page">
      <div class="header">
        <h1>🕵️ WHO'S THE SPY?</h1>
        <p style="color:#9ca3af">谁是卧底 — English Edition</p>
      </div>
      <div class="card">
        <button class="btn btn-primary" onclick="startGame()">🎮 START GAME</button>
        <button class="btn" style="background:rgba(255,255,255,0.1);color:#22d3ee" onclick="showRules()">📖 HOW TO PLAY</button>
      </div>
    </div>

    <div id="room-page" class="page hidden">
      <div class="header"><h1>ROOM</h1></div>
      <div class="card">
        <p style="color:#9ca3af;text-align:center">Room Code</p>
        <div class="room-code" id="room-code">ABCD</div>
        <div id="player-list"></div>
      </div>
      <div class="card">
        <button class="btn btn-primary" onclick="showWords()">🚀 START</button>
        <button class="btn" style="background:rgba(239,68,68,0.2);color:#ef4444" onclick="backToHome()">← BACK</button>
      </div>
    </div>

    <div id="word-page" class="page hidden">
      <div class="header"><h1>YOUR WORD</h1></div>
      <div class="card">
        <div class="word-display">
          <div id="player-role" style="font-size:18px;color:#e879f9;margin-bottom:10px">CIVILIAN</div>
          <h2 id="player-word">Apple/苹果</h2>
        </div>
      </div>
      <div class="card" id="judge-view" style="display:none">
        <h3 style="color:#22d3ee;margin-bottom:16px">Judge View</h3>
        <div id="all-players"></div>
      </div>
      <div class="card">
        <button class="btn btn-primary" onclick="nextPlayer()">➡️ NEXT PLAYER</button>
        <button class="btn" style="background:rgba(239,68,68,0.2);color:#ef4444" onclick="endGame()">🏠 END</button>
      </div>
    </div>
  </div>

  <script>
    const wordPairs = [
      { civilian: 'Apple/苹果', spy: 'Orange/橙子' },
      { civilian: 'Dog/狗', spy: 'Cat/猫' },
      { civilian: 'Milk Tea/奶茶', spy: 'Coffee/咖啡' },
      { civilian: 'Summer/夏天', spy: 'Winter/冬天' },
      { civilian: 'Teacher/老师', spy: 'Professor/教授' },
      { civilian: 'Movie/电影', spy: 'Drama/电视剧' },
    ];

    let game = { players: [], current: null, wordPair: null, currentIndex: 0 };

    function generateCode() {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      let code = '';
      for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)];
      return code;
    }

    function startGame() {
      game.wordPair = wordPairs[Math.floor(Math.random() * wordPairs.length)];
      game.players = [
        { name: 'You', role: 'judge', word: 'ALL WORDS' },
        { name: 'Player 1', role: 'civilian', word: game.wordPair.civilian },
        { name: 'Player 2', role: 'spy', word: game.wordPair.spy },
        { name: 'Player 3', role: 'civilian', word: game.wordPair.civilian }
      ];
      document.getElementById('room-code').textContent = generateCode();
      updatePlayerList();
      showPage('room-page');
    }

    function updatePlayerList() {
      document.getElementById('player-list').innerHTML = game.players.map(p =>
        \`<div class="player-item"><span>\${p.name}</span><span style="color:\${p.role==='judge'?'#22d3ee':p.role==='spy'?'#e879f9':'#a855f7'}">\${p.role.toUpperCase()}</span></div>\`
      ).join('');
    }

    function showWords() {
      game.currentIndex = 0;
      game.current = game.players[0];
      showWordPage();
      showPage('word-page');
    }

    function showWordPage() {
      const p = game.current;
      document.getElementById('player-role').textContent = p.role.toUpperCase();
      document.getElementById('player-role').style.color = p.role === 'judge' ? '#22d3ee' : p.role === 'spy' ? '#e879f9' : '#a855f7';
      document.getElementById('player-word').textContent = p.word;
      document.getElementById('judge-view').style.display = p.role === 'judge' ? 'block' : 'none';
      if (p.role === 'judge') {
        document.getElementById('all-players').innerHTML = game.players.map(x =>
          \`<div class="player-item"><span>\${x.name}</span><span style="color:#9ca3af">\${x.word}</span></div>\`
        ).join('');
      }
    }

    function nextPlayer() {
      game.currentIndex = (game.currentIndex + 1) % game.players.length;
      game.current = game.players[game.currentIndex];
      showWordPage();
    }

    function endGame() { showPage('home-page'); }
    function backToHome() { showPage('home-page'); }
    function showRules() { alert('游戏规则：\\n1. 法官知道所有词语\\n2. 平民拿到相同的词\\n3. 卧底拿到不同的词\\n4. 通过描述找出卧底！'); }
    function showPage(id) { document.querySelectorAll('.page').forEach(p => p.classList.add('hidden')); document.getElementById(id).classList.remove('hidden'); }
  </script>
</body>
</html>`;

serve((req) => {
  return new Response(HTML_CONTENT, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
    },
  });
});
