import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const HTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
  <title>谁是卧底 - 多人版</title>
  <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 100%);
      min-height: 100vh;
      color: #fff;
    }
    .page { min-height: 100vh; padding: 20px; display: flex; flex-direction: column; }
    .header { text-align: center; padding: 20px 0; }
    .header h1 { font-size: 28px; background: linear-gradient(90deg, #22d3ee, #e879f9); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .card { background: rgba(255,255,255,0.05); border: 1px solid rgba(34, 211, 238, 0.3); border-radius: 16px; padding: 24px; margin-bottom: 16px; }
    .btn { display: block; width: 100%; padding: 16px; margin-bottom: 12px; border-radius: 12px; border: none; font-weight: bold; font-size: 16px; cursor: pointer; text-align: center; }
    .btn-primary { background: linear-gradient(135deg, #22d3ee 0%, #0891b2 100%); color: #000; }
    .btn-secondary { background: rgba(255,255,255,0.1); color: #22d3ee; border: 1px solid rgba(34, 211, 238, 0.3); }
    .input { width: 100%; padding: 16px; border-radius: 12px; border: 1px solid rgba(34, 211, 238, 0.3); background: rgba(255,255,255,0.05); color: #fff; font-size: 16px; margin-bottom: 12px; }
    .room-code { text-align: center; font-size: 48px; color: #22d3ee; letter-spacing: 8px; margin: 20px 0; font-weight: bold; }
    .player-list { margin-top: 20px; }
    .player-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; background: rgba(255,255,255,0.03); border-radius: 8px; margin-bottom: 8px; }
    .word-display { text-align: center; padding: 40px 20px; }
    .word-display h2 { font-size: 42px; color: #22d3ee; margin: 20px 0; }
    .hidden { display: none !important; }
    .status { text-align: center; color: #9ca3af; margin: 10px 0; }
    .error { color: #ef4444; text-align: center; margin: 10px 0; }
  </style>
</head>
<body>
  <div id="app">
    <!-- 首页 -->
    <div id="home-page" class="page">
      <div class="header">
        <h1>🕵️ WHO'S THE SPY?</h1>
        <p style="color:#9ca3af">多人实时版</p>
      </div>
      <div class="card">
        <input type="text" id="player-name" class="input" placeholder="输入你的名字" maxlength="20">
        <button class="btn btn-primary" onclick="createRoom()">🏠 创建房间</button>
        <button class="btn btn-secondary" onclick="showJoin()">🔑 加入房间</button>
      </div>
    </div>

    <!-- 加入房间 -->
    <div id="join-page" class="page hidden">
      <div class="header"><h1>加入房间</h1></div>
      <div class="card">
        <input type="text" id="join-name" class="input" placeholder="你的名字">
        <input type="text" id="join-code" class="input" placeholder="房间号 (如: ABCD)" maxlength="4">
        <button class="btn btn-primary" onclick="joinRoom()">🚀 加入</button>
        <button class="btn btn-secondary" onclick="showPage('home-page')">← 返回</button>
      </div>
      <div id="join-error" class="error hidden"></div>
    </div>

    <!-- 房间等待 -->
    <div id="room-page" class="page hidden">
      <div class="header"><h1>房间</h1></div>
      <div class="card">
        <p style="color:#9ca3af;text-align:center">房间号</p>
        <div class="room-code" id="display-room-code">----</div>
        <p class="status" id="room-status">等待玩家加入...</p>
        <div id="room-players" class="player-list"></div>
      </div>
      <div class="card" id="host-controls">
        <button class="btn btn-primary" onclick="startGame()" id="start-btn" disabled>🎮 开始游戏 (需要3人以上)</button>
        <button class="btn btn-secondary" onclick="leaveRoom()">🏠 离开房间</button>
      </div>
    </div>

    <!-- 游戏页面 -->
    <div id="game-page" class="page hidden">
      <div class="header"><h1>你的词语</h1></div>
      <div class="card">
        <div class="word-display">
          <p style="color:#e879f9;font-size:18px" id="game-role">CIVILIAN</p>
          <h2 id="game-word">---</h2>
          <p style="color:#9ca3af;margin-top:20px">记住你的词语，准备描述！</p>
        </div>
      </div>
      <div class="card" id="judge-panel" style="display:none">
        <h3 style="color:#22d3ee;margin-bottom:16px">👨‍⚖️ 法官面板</h3>
        <div id="judge-players"></div>
      </div>
      <div class="card">
        <button class="btn btn-secondary" onclick="showPage('room-page')">← 返回房间</button>
      </div>
    </div>
  </div>

  <script>
    // Supabase配置
    const SUPABASE_URL = 'https://mp-api.meoo.host/sb-api';
    const SUPABASE_KEY = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzgxMzM3NjM2LCJleHAiOjEzMjkxOTc3NjM2fQ._9Yh08IrLNV35-Vi92qDrjHcUpg0PCVZ3nO-us_xa9o';
    const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

    // 游戏数据
    let currentRoom = null;
    let currentPlayer = null;
    let isHost = false;
    let subscription = null;

    const wordPairs = [
      { civilian: 'Apple/苹果', spy: 'Orange/橙子' },
      { civilian: 'Dog/狗', spy: 'Cat/猫' },
      { civilian: 'Milk Tea/奶茶', spy: 'Coffee/咖啡' },
      { civilian: 'Summer/夏天', spy: 'Winter/冬天' },
      { civilian: 'Teacher/老师', spy: 'Professor/教授' },
    ];

    function generateCode() {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      let code = '';
      for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)];
      return code;
    }

    async function createRoom() {
      const name = document.getElementById('player-name').value.trim();
      if (!name) { alert('请输入名字'); return; }

      const roomCode = generateCode();
      const roomId = 'room_' + Date.now();
      const wordPair = wordPairs[Math.floor(Math.random() * wordPairs.length)];

      try {
        // 创建房间
        await supabase.from('game_rooms').insert({
          id: roomId,
          room_code: roomCode,
          status: 'waiting',
          word_civilian: wordPair.civilian,
          word_spy: wordPair.spy
        });

        // 创建玩家（法官）
        await supabase.from('game_players').insert({
          room_id: roomId,
          player_name: name,
          role: 'judge',
          word: 'ALL WORDS'
        });

        currentRoom = { id: roomId, code: roomCode, wordPair };
        currentPlayer = { name, role: 'judge' };
        isHost = true;

        document.getElementById('display-room-code').textContent = roomCode;
        showPage('room-page');
        subscribeToRoom(roomId);
      } catch (e) {
        alert('创建房间失败: ' + e.message);
      }
    }

    async function joinRoom() {
      const name = document.getElementById('join-name').value.trim();
      const code = document.getElementById('join-code').value.trim().toUpperCase();
      const errorDiv = document.getElementById('join-error');

      if (!name || !code) { errorDiv.textContent = '请填写完整信息'; errorDiv.classList.remove('hidden'); return; }

      try {
        // 查找房间
        const { data: rooms } = await supabase.from('game_rooms').select('*').eq('room_code', code);
        if (!rooms || rooms.length === 0) { errorDiv.textContent = '房间不存在'; errorDiv.classList.remove('hidden'); return; }

        const room = rooms[0];
        if (room.status !== 'waiting') { errorDiv.textContent = '游戏已开始'; errorDiv.classList.remove('hidden'); return; }

        // 检查人数
        const { data: players } = await supabase.from('game_players').select('*').eq('room_id', room.id);
        if (players && players.length >= 8) { errorDiv.textContent = '房间已满'; errorDiv.classList.remove('hidden'); return; }

        // 加入房间
        await supabase.from('game_players').insert({
          room_id: room.id,
          player_name: name,
          role: null,
          word: null
        });

        currentRoom = { id: room.id, code: code, wordPair: { civilian: room.word_civilian, spy: room.word_spy } };
        currentPlayer = { name, role: null };
        isHost = false;

        document.getElementById('display-room-code').textContent = code;
        showPage('room-page');
        subscribeToRoom(room.id);
      } catch (e) {
        errorDiv.textContent = '加入失败: ' + e.message;
        errorDiv.classList.remove('hidden');
      }
    }

    function subscribeToRoom(roomId) {
      if (subscription) subscription.unsubscribe();

      subscription = supabase
        .channel('room_' + roomId)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'game_players', filter: 'room_id=eq.' + roomId }, (payload) => {
          updatePlayerList(roomId);
        })
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'game_rooms', filter: 'id=eq.' + roomId }, (payload) => {
          if (payload.new.status === 'playing') {
            showGamePage();
          }
        })
        .subscribe();

      updatePlayerList(roomId);
    }

    async function updatePlayerList(roomId) {
      const { data: players } = await supabase.from('game_players').select('*').eq('room_id', roomId);
      if (!players) return;

      const list = document.getElementById('room-players');
      list.innerHTML = players.map(p => {
        const roleColor = p.role === 'judge' ? '#22d3ee' : p.role === 'spy' ? '#e879f9' : p.role ? '#a855f7' : '#9ca3af';
        const roleText = p.role ? p.role.toUpperCase() : 'WAITING';
        return \`<div class="player-item"><span>\${p.player_name}</span><span style="color:\${roleColor}">\${roleText}</span></div>\`;
      }).join('');

      document.getElementById('room-status').textContent = \`\${players.length} 人在房间\`;

      if (isHost) {
        const startBtn = document.getElementById('start-btn');
        startBtn.disabled = players.length < 3;
        startBtn.textContent = players.length < 3 ? \`开始游戏 (需要\${3-players.length}人)\` : '🎮 开始游戏';
      }
    }

    async function startGame() {
      if (!isHost || !currentRoom) return;

      const { data: players } = await supabase.from('game_players').select('*').eq('room_id', currentRoom.id);
      if (!players || players.length < 3) { alert('需要至少3人'); return; }

      // 分配角色
      const nonJudge = players.filter(p => p.role !== 'judge');
      const spyIndex = Math.floor(Math.random() * nonJudge.length);

      for (let i = 0; i < nonJudge.length; i++) {
        const isSpy = i === spyIndex;
        await supabase.from('game_players').update({
          role: isSpy ? 'spy' : 'civilian',
          word: isSpy ? currentRoom.wordPair.spy : currentRoom.wordPair.civilian
        }).eq('id', nonJudge[i].id);
      }

      // 更新房间状态
      await supabase.from('game_rooms').update({ status: 'playing' }).eq('id', currentRoom.id);
      showGamePage();
    }

    async function showGamePage() {
      if (!currentRoom) return;

      const { data: players } = await supabase.from('game_players').select('*').eq('room_id', currentRoom.id);
      const me = players.find(p => p.player_name === currentPlayer.name);

      if (me) {
        currentPlayer.role = me.role;
        document.getElementById('game-role').textContent = me.role.toUpperCase();
        document.getElementById('game-role').style.color = me.role === 'judge' ? '#22d3ee' : me.role === 'spy' ? '#e879f9' : '#a855f7';
        document.getElementById('game-word').textContent = me.word;

        if (me.role === 'judge') {
          document.getElementById('judge-panel').style.display = 'block';
          document.getElementById('judge-players').innerHTML = players.map(p =>
            \`<div class="player-item"><span>\${p.player_name}</span><span style="color:#9ca3af">\${p.word}</span></div>\`
          ).join('');
        } else {
          document.getElementById('judge-panel').style.display = 'none';
        }
      }

      showPage('game-page');
    }

    async function leaveRoom() {
      if (subscription) subscription.unsubscribe();
      if (currentRoom && !isHost) {
        await supabase.from('game_players').delete().eq('room_id', currentRoom.id).eq('player_name', currentPlayer.name);
      }
      currentRoom = null;
      currentPlayer = null;
      isHost = false;
      showPage('home-page');
    }

    function showJoin() {
      const name = document.getElementById('player-name').value.trim();
      document.getElementById('join-name').value = name;
      showPage('join-page');
    }

    function showPage(id) {
      document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
      document.getElementById(id).classList.remove('hidden');
    }
  </script>
</body>
</html>`;

serve((req) => {
  return new Response(HTML, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
    },
  });
});
