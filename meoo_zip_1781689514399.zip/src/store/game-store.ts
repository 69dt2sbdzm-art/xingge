import { create } from 'zustand';

// 游戏角色类型
export type Role = 'judge' | 'civilian' | 'spy';

// 玩家类型
export interface Player {
  id: string;
  nickname: string;
  avatar: string;
  role?: Role;
  word?: string;
  isOnline: boolean;
}

// 词语对（平民词 + 卧底词）
export interface WordPair {
  civilian: string;
  spy: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

// 投票状态
export interface Vote {
  voterId: string;
  targetId: string;
}

// 游戏阶段
type GamePhase = 'waiting' | 'describing' | 'voting' | 'result' | 'ended';

// 游戏状态
interface GameState {
  // 当前玩家
  currentPlayer: Player | null;
  // 房间内的所有玩家
  players: Player[];
  // 房间号
  roomCode: string;
  // 游戏是否开始
  isGameStarted: boolean;
  // 当前轮次
  currentRound: number;
  // 选中的词语对
  currentWordPair: WordPair | null;
  // 游戏阶段
  gamePhase: GamePhase;
  // 投票列表
  votes: Vote[];
  // 被淘汰的玩家
  eliminatedPlayers: string[];
  // 获胜方
  winner: 'civilian' | 'spy' | null;
  // 已使用的词语（避免重复）
  usedWordPairs: WordPair[];

  // Actions
  setCurrentPlayer: (player: Player) => void;
  addPlayer: (player: Player) => void;
  removePlayer: (playerId: string) => void;
  clearPlayers: () => void;
  setRoomCode: (code: string) => void;
  startGame: () => void;
  assignRoles: () => void;
  resetGame: () => void;
  setCurrentWordPair: (pair: WordPair) => void;
  // 投票相关
  startVoting: () => void;
  submitVote: (voterId: string, targetId: string) => void;
  endVoting: () => void;
  eliminatePlayer: (playerId: string) => void;
  nextRound: () => void;
  // 重新开始
  restartGame: () => void;
  // 词语管理
  addUsedWordPair: (pair: WordPair) => void;
  clearUsedWordPairs: () => void;
}

// 中英双语词语库（按难度分类）
export const wordPairs: WordPair[] = [
  // ========== 简单难度 (CET-4水平) ==========
  // 食物类
  { civilian: 'Milk Tea/奶茶', spy: 'Coffee/咖啡', difficulty: 'easy' },
  { civilian: 'Apple/苹果', spy: 'Orange/橙子', difficulty: 'easy' },
  { civilian: 'Pizza/披萨', spy: 'Burger/汉堡', difficulty: 'easy' },
  { civilian: 'Hot Pot/火锅', spy: 'BBQ/烧烤', difficulty: 'easy' },
  { civilian: 'Noodles/面条', spy: 'Rice/米饭', difficulty: 'easy' },
  { civilian: 'Cake/蛋糕', spy: 'Bread/面包', difficulty: 'easy' },
  { civilian: 'Ice Cream/冰淇淋', spy: 'Pudding/布丁', difficulty: 'easy' },

  // 动物类
  { civilian: 'Dog/狗', spy: 'Cat/猫', difficulty: 'easy' },
  { civilian: 'Tiger/老虎', spy: 'Lion/狮子', difficulty: 'easy' },
  { civilian: 'Panda/熊猫', spy: 'Koala/考拉', difficulty: 'easy' },
  { civilian: 'Rabbit/兔子', spy: 'Hamster/仓鼠', difficulty: 'easy' },

  // 日常物品
  { civilian: 'Phone/手机', spy: 'Computer/电脑', difficulty: 'easy' },
  { civilian: 'Book/书', spy: 'Magazine/杂志', difficulty: 'easy' },
  { civilian: 'Car/汽车', spy: 'Bus/公交车', difficulty: 'easy' },
  { civilian: 'Bike/自行车', spy: 'Motorcycle/摩托车', difficulty: 'easy' },
  { civilian: 'Umbrella/雨伞', spy: 'Raincoat/雨衣', difficulty: 'easy' },

  // 地点类
  { civilian: 'Beach/海滩', spy: 'Pool/泳池', difficulty: 'easy' },
  { civilian: 'Park/公园', spy: 'Garden/花园', difficulty: 'easy' },
  { civilian: 'School/学校', spy: 'Library/图书馆', difficulty: 'easy' },
  { civilian: 'Hospital/医院', spy: 'Clinic/诊所', difficulty: 'easy' },

  // 季节/天气
  { civilian: 'Summer/夏天', spy: 'Winter/冬天', difficulty: 'easy' },
  { civilian: 'Sunny/晴天', spy: 'Cloudy/多云', difficulty: 'easy' },
  { civilian: 'Rain/雨', spy: 'Snow/雪', difficulty: 'easy' },

  // ========== 中等难度 (CET-6水平) ==========
  // 职业类
  { civilian: 'Doctor/医生', spy: 'Nurse/护士', difficulty: 'medium' },
  { civilian: 'Teacher/老师', spy: 'Professor/教授', difficulty: 'medium' },
  { civilian: 'Security Guard/保安', spy: 'Bodyguard/保镖', difficulty: 'medium' },
  { civilian: 'Chef/厨师', spy: 'Baker/烘焙师', difficulty: 'medium' },
  { civilian: 'Journalist/记者', spy: 'Editor/编辑', difficulty: 'medium' },
  { civilian: 'Actor/演员', spy: 'Singer/歌手', difficulty: 'medium' },

  // 交通类
  { civilian: 'Subway/地铁', spy: 'High-speed Rail/高铁', difficulty: 'medium' },
  { civilian: 'Flight/飞机', spy: 'Train/火车', difficulty: 'medium' },
  { civilian: 'Taxi/出租车', spy: 'Uber/网约车', difficulty: 'medium' },

  // 社交/生活
  { civilian: 'WeChat/微信', spy: 'QQ', difficulty: 'medium' },
  { civilian: 'Interview/面试', spy: 'Blind Date/相亲', difficulty: 'medium' },
  { civilian: 'Overtime/加班', spy: 'Stay up late/熬夜', difficulty: 'medium' },
  { civilian: 'Resign/辞职', spy: 'Job-hop/跳槽', difficulty: 'medium' },
  { civilian: 'Wedding/婚礼', spy: 'Funeral/葬礼', difficulty: 'medium' },
  { civilian: 'Birthday/生日', spy: 'Anniversary/纪念日', difficulty: 'medium' },

  // 娱乐类
  { civilian: 'Movie/电影', spy: 'Drama/电视剧', difficulty: 'medium' },
  { civilian: 'Concert/演唱会', spy: 'Musical/音乐剧', difficulty: 'medium' },
  { civilian: 'Guitar/吉他', spy: 'Violin/小提琴', difficulty: 'medium' },
  { civilian: 'Basketball/篮球', spy: 'Football/足球', difficulty: 'medium' },
  { civilian: 'Game/游戏', spy: 'Sport/运动', difficulty: 'medium' },

  // 地点类
  { civilian: 'Restaurant/餐厅', spy: 'Cafe/咖啡厅', difficulty: 'medium' },
  { civilian: 'Hotel/酒店', spy: 'Hostel/青旅', difficulty: 'medium' },
  { civilian: 'Mountain/山', spy: 'Hill/丘陵', difficulty: 'medium' },
  { civilian: 'River/河', spy: 'Lake/湖', difficulty: 'medium' },

  // 关系类（搞笑经典）
  { civilian: 'Wife/老婆', spy: 'Mother-in-law/丈母娘', difficulty: 'medium' },
  { civilian: 'Boyfriend/男朋友', spy: 'Male Friend/男闺蜜', difficulty: 'medium' },
  { civilian: 'Girlfriend/女朋友', spy: 'Female Friend/女闺蜜', difficulty: 'medium' },
  { civilian: 'Ex/前任', spy: 'Current/现任', difficulty: 'medium' },

  // ========== 困难难度 (高级/专业) ==========
  // 政治/历史
  { civilian: 'Democracy/民主', spy: 'Republic/共和', difficulty: 'hard' },
  { civilian: 'Capitalism/资本主义', spy: 'Socialism/社会主义', difficulty: 'hard' },
  { civilian: 'Renaissance/文艺复兴', spy: 'Baroque/巴洛克', difficulty: 'hard' },
  { civilian: 'Monarchy/君主制', spy: 'Dictatorship/独裁制', difficulty: 'hard' },

  // 文学/修辞
  { civilian: 'Metaphor/隐喻', spy: 'Simile/明喻', difficulty: 'hard' },
  { civilian: 'Allegory/寓言', spy: 'Symbolism/象征主义', difficulty: 'hard' },
  { civilian: 'Irony/反讽', spy: 'Sarcasm/讽刺', difficulty: 'hard' },
  { civilian: 'Philosophy/哲学', spy: 'Psychology/心理学', difficulty: 'hard' },
  { civilian: 'Poetry/诗歌', spy: 'Prose/散文', difficulty: 'hard' },

  // 科学/技术
  { civilian: 'Theory/理论', spy: 'Hypothesis/假设', difficulty: 'hard' },
  { civilian: 'Evolution/进化', spy: 'Revolution/革命', difficulty: 'hard' },
  { civilian: 'Climate/气候', spy: 'Weather/天气', difficulty: 'hard' },
  { civilian: 'Data/数据', spy: 'Information/信息', difficulty: 'hard' },

  // 艺术/文化
  { civilian: 'Classic/古典', spy: 'Romantic/浪漫', difficulty: 'hard' },
  { civilian: 'Abstract/抽象', spy: 'Concrete/具象', difficulty: 'hard' },
  { civilian: 'Comedy/喜剧', spy: 'Tragedy/悲剧', difficulty: 'hard' },
  { civilian: 'Novel/小说', spy: 'Biography/传记', difficulty: 'hard' },

  // 商业/经济
  { civilian: 'Revenue/收入', spy: 'Profit/利润', difficulty: 'hard' },
  { civilian: 'Asset/资产', spy: 'Liability/负债', difficulty: 'hard' },
  { civilian: 'Strategy/战略', spy: 'Tactics/战术', difficulty: 'hard' },
  { civilian: 'Leader/领导', spy: 'Manager/经理', difficulty: 'hard' },
];

// 生成随机房间号
export const generateRoomCode = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

// 生成玩家头像颜色
export const generateAvatarColor = (index: number): string => {
  const colors = [
    'from-cyan-400 to-blue-500',
    'from-fuchsia-500 to-purple-600',
    'from-lime-400 to-green-500',
    'from-amber-400 to-orange-500',
    'from-rose-400 to-pink-500',
    'from-violet-400 to-indigo-500',
  ];
  return colors[index % colors.length];
};

// 生成模拟玩家（用于单人测试模式）
export const generateMockPlayers = (count: number): Player[] => {
  const aiNames = ['Alice', 'Bob', 'Carol', 'David', 'Emma', 'Frank', 'Grace', 'Henry', 'Ivy', 'Jack'];
  const players: Player[] = [];

  for (let i = 0; i < count; i++) {
    players.push({
      id: `ai-${i + 2}`,
      nickname: aiNames[i % aiNames.length],
      avatar: '',
      isOnline: true
    });
  }

  return players;
};

// 随机选择词语对（避免重复）
export const getRandomWordPair = (difficulty?: 'easy' | 'medium' | 'hard', usedPairs: WordPair[] = []): WordPair => {
  const filtered = difficulty
    ? wordPairs.filter(w => w.difficulty === difficulty)
    : wordPairs;
  // 过滤掉已使用的词语
  const available = filtered.filter(w =>
    !usedPairs.some(used => used.civilian === w.civilian && used.spy === w.spy)
  );
  // 如果所有词语都用过了，返回随机一个
  const pool = available.length > 0 ? available : filtered;
  return pool[Math.floor(Math.random() * pool.length)];
};

export const useGameStore = create<GameState>((set, get) => ({
  currentPlayer: null,
  players: [],
  roomCode: '',
  isGameStarted: false,
  currentRound: 0,
  currentWordPair: null,
  gamePhase: 'waiting',
  votes: [],
  eliminatedPlayers: [],
  winner: null,
  usedWordPairs: [],

  setCurrentPlayer: (player) => set({ currentPlayer: player }),

  addPlayer: (player) => set((state) => ({
    players: [...state.players, player]
  })),

  removePlayer: (playerId) => set((state) => ({
    players: state.players.filter(p => p.id !== playerId)
  })),

  clearPlayers: () => set({ players: [] }),

  setRoomCode: (code) => set({ roomCode: code }),

  startGame: () => set({ isGameStarted: true, currentRound: 1, gamePhase: 'describing' }),

  setCurrentWordPair: (pair) => set({ currentWordPair: pair }),

  assignRoles: () => {
    const { players, currentWordPair } = get();
    if (!currentWordPair || players.length < 3) return;

    // 随机选择法官
    const judgeIndex = Math.floor(Math.random() * players.length);

    // 随机选择卧底（不能是法官）
    let spyIndex;
    do {
      spyIndex = Math.floor(Math.random() * players.length);
    } while (spyIndex === judgeIndex);

    // 分配角色
    const updatedPlayers = players.map((player, index) => {
      if (index === judgeIndex) {
        return { ...player, role: 'judge' as Role, word: 'ALL WORDS' };
      } else if (index === spyIndex) {
        return { ...player, role: 'spy' as Role, word: currentWordPair.spy };
      } else {
        return { ...player, role: 'civilian' as Role, word: currentWordPair.civilian };
      }
    });

    set({ players: updatedPlayers });
  },

  // 开始投票阶段
  startVoting: () => set({ gamePhase: 'voting', votes: [] }),

  // 提交投票
  submitVote: (voterId: string, targetId: string) => set((state) => ({
    votes: [...state.votes, { voterId, targetId }]
  })),

  // 结束投票，计算结果
  endVoting: () => {
    const { votes, players, eliminatedPlayers } = get();

    // 统计票数
    const voteCount: Record<string, number> = {};
    votes.forEach(vote => {
      voteCount[vote.targetId] = (voteCount[vote.targetId] || 0) + 1;
    });

    // 找出得票最多的玩家
    let maxVotes = 0;
    let eliminatedId = '';
    Object.entries(voteCount).forEach(([playerId, count]) => {
      if (count > maxVotes) {
        maxVotes = count;
        eliminatedId = playerId;
      }
    });

    if (eliminatedId) {
      const eliminatedPlayer = players.find(p => p.id === eliminatedId);
      set({
        eliminatedPlayers: [...eliminatedPlayers, eliminatedId],
        gamePhase: 'result',
        winner: eliminatedPlayer?.role === 'spy' ? 'civilian' : null
      });
    }
  },

  // 淘汰玩家
  eliminatePlayer: (playerId: string) => set((state) => ({
    eliminatedPlayers: [...state.eliminatedPlayers, playerId]
  })),

  // 下一轮
  nextRound: () => set((state) => ({
    currentRound: state.currentRound + 1,
    gamePhase: 'describing',
    votes: []
  })),

  // 重新开始游戏（保留玩家，重新分配角色和词语）
  restartGame: () => set((state) => {
    // 将当前词语加入已使用列表
    const updatedUsedPairs = state.currentWordPair
      ? [...state.usedWordPairs, state.currentWordPair]
      : state.usedWordPairs;

    // 选择新词语（避免重复）
    const newWordPair = getRandomWordPair('easy', updatedUsedPairs);

    // 重新分配角色 - id='1' 的玩家固定为法官（测试模式中的当前用户）
    const judgeId = '1';

    // 获取所有玩家ID
    const allPlayerIds = state.players.map(p => p.id);

    // 从其他玩家中选一个作为卧底
    const otherPlayerIds = allPlayerIds.filter(id => id !== judgeId);
    const spyId = otherPlayerIds[Math.floor(Math.random() * otherPlayerIds.length)];

    // 重新分配所有玩家角色
    const reassignedPlayers = state.players.map((player) => {
      if (player.id === judgeId) {
        return { ...player, role: 'judge' as Role, word: 'ALL WORDS' };
      } else if (player.id === spyId) {
        return { ...player, role: 'spy' as Role, word: newWordPair.spy };
      } else {
        return { ...player, role: 'civilian' as Role, word: newWordPair.civilian };
      }
    });

    // 更新 currentPlayer - 测试模式中 currentPlayer 就是 id='1'
    const currentPlayerId = state.currentPlayer?.id;
    let updatedCurrentPlayer = state.currentPlayer;
    if (currentPlayerId === judgeId) {
      updatedCurrentPlayer = { ...state.currentPlayer!, role: 'judge' as Role, word: 'ALL WORDS' };
    } else if (currentPlayerId === spyId) {
      updatedCurrentPlayer = { ...state.currentPlayer!, role: 'spy' as Role, word: newWordPair.spy };
    } else if (currentPlayerId) {
      updatedCurrentPlayer = { ...state.currentPlayer!, role: 'civilian' as Role, word: newWordPair.civilian };
    }

    return {
      players: reassignedPlayers,
      currentPlayer: updatedCurrentPlayer,
      currentWordPair: newWordPair,
      usedWordPairs: updatedUsedPairs,
      currentRound: 1,
      gamePhase: 'describing',
      votes: [],
      eliminatedPlayers: [],
      winner: null,
      isGameStarted: true
    };
  }),

  resetGame: () => set({
    currentPlayer: null,
    players: [],
    roomCode: '',
    isGameStarted: false,
    currentRound: 0,
    currentWordPair: null,
    gamePhase: 'waiting',
    votes: [],
    eliminatedPlayers: [],
    winner: null,
    usedWordPairs: [],
  }),

  // 添加已使用词语
  addUsedWordPair: (pair) => set((state) => ({
    usedWordPairs: [...state.usedWordPairs, pair]
  })),

  // 清空已使用词语
  clearUsedWordPairs: () => set({ usedWordPairs: [] }),
}));
