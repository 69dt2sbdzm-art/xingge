export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/join/index',
    'pages/room/index',
    'pages/word/index',
    'pages/vote/index',
    'pages/result/index'
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#0a0a0f',
    navigationBarTitleText: "Who's the Spy? ",
    navigationBarTextStyle: 'white',
    backgroundColor: '#0a0a0f'
  }
});
