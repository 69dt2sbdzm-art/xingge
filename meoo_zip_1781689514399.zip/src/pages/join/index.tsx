import { useState } from 'react';
import { View, Text, Input } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useGameStore, generateAvatarColor } from '@/store/game-store';

export default function JoinPage() {
  const [nickname, setNickname] = useState('');
  const { roomCode, setCurrentPlayer, addPlayer } = useGameStore();

  const handleJoin = () => {
    if (!nickname.trim()) {
      Taro.showToast({
        title: '请输入昵称',
        icon: 'none'
      });
      return;
    }

    // 创建当前玩家
    const player = {
      id: Date.now().toString(),
      nickname: nickname.trim(),
      avatar: generateAvatarColor(0),
      isOnline: true
    };

    setCurrentPlayer(player);
    addPlayer(player);

    // 跳转到房间页面
    Taro.navigateTo({
      url: '/pages/room/index'
    });
  };

  const handleBack = () => {
    Taro.navigateBack();
  };

  return (
    <View className="min-h-screen bg-background flex flex-col px-6 py-8">
      {/* 扫描线效果背景 */}
      <View 
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(34, 211, 238, 0.03) 2px, rgba(34, 211, 238, 0.03) 4px)'
        }}
      />

      {/* 页面标题 */}
      <View className="mb-8">
        <Text className="text-xs text-neon-cyan tracking-widest mb-4">PLAYER.REGISTRATION</Text>
      </View>

      {/* 输入区域 */}
      <View className="flex-1 flex flex-col">
        {/* 房间号显示 */}
        <View className="mb-8">
          <Text className="text-sm text-muted-foreground mb-2">ROOM CODE</Text>
          <View 
            className="py-4 px-4 rounded-lg border border-solid"
            style={{
              background: '#111118',
              borderColor: 'rgba(34, 211, 238, 0.2)'
            }}
          >
            <Text 
              className="text-2xl font-bold text-center tracking-widest"
              style={{ color: '#22d3ee' }}
            >
              {roomCode}
            </Text>
          </View>
        </View>

        {/* 昵称输入 */}
        <View className="mb-8">
          <Text className="text-sm text-muted-foreground mb-2">ENTER NICKNAME</Text>
          <View className="relative">
            <Input
              type="text"
              value={nickname}
              onInput={(e) => setNickname(e.detail.value)}
              placeholder="Your name..."
              placeholderClass="text-gray-600"
              className="w-full py-4 px-4 rounded-lg text-cyan-400"
              style={{
                background: '#111118',
                border: '1px solid rgba(34, 211, 238, 0.3)'
              }}
            />
            <Text 
              className="absolute right-4 top-1/2 -translate-y-1/2 text-xs"
              style={{ color: 'rgba(34, 211, 238, 0.5)' }}
            >
              &gt;
            </Text>
          </View>
        </View>

        {/* 按钮区域 */}
        <View className="mt-auto">
          {/* 加入按钮 */}
          <View 
            className="w-full py-4 rounded-lg flex items-center justify-center mb-4 cursor-pointer"
            style={{
              background: '#22d3ee',
              boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
            }}
            onClick={handleJoin}
          >
            <Text className="text-black font-bold text-lg uppercase tracking-wider">
              JOIN ROOM
            </Text>
          </View>

          {/* 返回按钮 */}
          <View 
            className="w-full py-4 rounded-lg flex items-center justify-center border border-solid cursor-pointer"
            style={{
              borderColor: 'rgba(232, 121, 249, 0.3)',
              background: 'transparent'
            }}
            onClick={handleBack}
          >
            <Text className="text-fuchsia-400 font-bold text-sm uppercase tracking-wider">
              BACK
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}
