export default definePageConfig({
  navigationBarTitleText: '加入游戏',
  navigationBarBackgroundColor: '#0a0a0f',
  navigationBarTextStyle: 'white'
});
