import { useState } from 'react';
import { View, Text } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useGameStore, Player } from '@/store/game-store';

export default function VotePage() {
  const { 
    players, 
    currentPlayer, 
    gamePhase,
    votes,
    submitVote,
    endVoting,
    eliminatedPlayers,
    currentRound,
    startVoting
  } = useGameStore();

  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null);
  const [hasVoted, setHasVoted] = useState(false);

  const isJudge = currentPlayer?.role === 'judge';
  const isEliminated = currentPlayer && eliminatedPlayers.includes(currentPlayer.id);
  
  // 获取可投票的玩家（排除法官和已被淘汰的）
  const votablePlayers = players.filter(p => 
    p.id !== currentPlayer?.id && 
    p.role !== 'judge' && 
    !eliminatedPlayers.includes(p.id)
  );

  // 获取投票统计
  const voteCount: Record<string, number> = {};
  votes.forEach(vote => {
    voteCount[vote.targetId] = (voteCount[vote.targetId] || 0) + 1;
  });

  const handleVote = () => {
    if (!selectedPlayer || !currentPlayer) return;
    submitVote(currentPlayer.id, selectedPlayer);
    setHasVoted(true);
    Taro.showToast({ title: 'Voted!', icon: 'success' });
  };

  const handleEndVoting = () => {
    endVoting();
    Taro.navigateTo({ url: '/pages/result/index' });
  };

  const handleStartVoting = () => {
    startVoting();
  };

  // 法官控制面板
  if (isJudge) {
    return (
      <View className="min-h-screen bg-background flex flex-col px-6 py-8">
        <View className="mb-6">
          <Text className="text-xs text-neon-cyan tracking-widest">JUDGE CONTROL</Text>
          <Text className="text-2xl font-bold text-white mt-2">ROUND {currentRound}</Text>
        </View>

        {gamePhase === 'describing' && (
          <View className="flex-1 flex flex-col items-center justify-center">
            <Text className="text-gray-400 mb-8 text-center">
              Players are describing their words...{'\n'}
              Click START VOTING when everyone is ready.
            </Text>
            <View 
              className="w-full py-4 rounded-lg flex items-center justify-center cursor-pointer"
              style={{
                background: 'linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%)',
                boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
              }}
              onClick={handleStartVoting}
            >
              <Text className="text-black font-bold text-lg">START VOTING</Text>
            </View>
          </View>
        )}

        {gamePhase === 'voting' && (
          <>
            <View className="mb-4">
              <Text className="text-sm text-gray-400">Voting in progress...</Text>
              <Text className="text-xs text-gray-500 mt-1">
                {votes.length} / {players.filter(p => p.role !== 'judge' && !eliminatedPlayers.includes(p.id)).length} voted
              </Text>
            </View>

            <View className="flex-1">
              {players.filter(p => !eliminatedPlayers.includes(p.id) && p.role !== 'judge').map((player) => (
                <View 
                  key={player.id}
                  className="flex items-center justify-between p-4 rounded-lg mb-3"
                  style={{ background: '#111118', border: '1px solid rgba(34, 211, 238, 0.2)' }}
                >
                  <Text className="text-white font-bold">{player.nickname}</Text>
                  <Text className="text-cyan-400">{voteCount[player.id] || 0} votes</Text>
                </View>
              ))}
            </View>

            <View 
              className="w-full py-4 rounded-lg flex items-center justify-center cursor-pointer mt-6"
              style={{
                background: 'linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%)',
                boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
              }}
              onClick={handleEndVoting}
            >
              <Text className="text-black font-bold text-lg">END VOTING & REVEAL</Text>
            </View>
          </>
        )}
      </View>
    );
  }

  // 普通玩家投票界面
  if (gamePhase === 'voting' && !isEliminated) {
    return (
      <View className="min-h-screen bg-background flex flex-col px-6 py-8">
        <View className="mb-6">
          <Text className="text-xs text-neon-cyan tracking-widest">VOTING PHASE</Text>
          <Text className="text-2xl font-bold text-white mt-2">WHO IS THE SPY?</Text>
        </View>

        {!hasVoted ? (
          <>
            <Text className="text-gray-400 mb-6">Select a player you suspect:</Text>
            
            <View className="flex-1 space-y-3">
              {votablePlayers.map((player) => (
                <View
                  key={player.id}
                  className="p-4 rounded-lg cursor-pointer"
                  style={{
                    background: selectedPlayer === player.id ? 'rgba(34, 211, 238, 0.2)' : '#111118',
                    border: `2px solid ${selectedPlayer === player.id ? '#22d3ee' : 'rgba(34, 211, 238, 0.2)'}`
                  }}
                  onClick={() => setSelectedPlayer(player.id)}
                >
                  <View className="flex items-center gap-3">
                    <View 
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ background: 'linear-gradient(135deg, #22d3ee, #3b82f6)' }}
                    >
                      <Text className="text-black font-bold">
                        {player.nickname.charAt(0).toUpperCase()}
                      </Text>
                    </View>
                    <Text className="text-white font-bold text-lg">{player.nickname}</Text>
                  </View>
                </View>
              ))}
            </View>

            <View 
              className={`w-full py-4 rounded-lg flex items-center justify-center mt-6 cursor-pointer ${
                selectedPlayer ? '' : 'opacity-50'
              }`}
              style={{
                background: selectedPlayer ? 'linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%)' : '#374151',
                boxShadow: selectedPlayer ? '0 0 20px rgba(34, 211, 238, 0.4)' : 'none'
              }}
              onClick={handleVote}
            >
              <Text className="text-black font-bold text-lg">CONFIRM VOTE</Text>
            </View>
          </>
        ) : (
          <View className="flex-1 flex flex-col items-center justify-center">
            <View 
              className="w-20 h-20 rounded-full flex items-center justify-center mb-6"
              style={{ background: 'rgba(34, 211, 238, 0.2)', border: '2px solid #22d3ee' }}
            >
              <Text className="text-4xl">✓</Text>
            </View>
            <Text className="text-white text-xl font-bold mb-2">VOTED!</Text>
            <Text className="text-gray-400 text-center">
              Waiting for other players...{'\n'}
              Judge will reveal the result soon.
            </Text>
          </View>
        )}
      </View>
    );
  }

  // 被淘汰或等待状态
  return (
    <View className="min-h-screen bg-background flex flex-col px-6 py-8 items-center justify-center">
      <Text className="text-gray-400 text-center">
        {isEliminated 
          ? 'You have been eliminated.\nWait for the game to end.' 
          : 'Waiting for judge to start voting...'}
      </Text>
    </View>
  );
}
