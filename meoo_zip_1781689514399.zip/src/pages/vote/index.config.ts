export default definePageConfig({
  navigationBarTitleText: 'Vote',
  navigationStyle: 'custom',
});
