import { useEffect } from 'react';
import { View, Text, Image } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useGameStore, generateRoomCode, generateMockPlayers, getRandomWordPair } from '@/store/game-store';

export default function IndexPage() {
  const { setRoomCode, addPlayer, setCurrentPlayer, setRoomCode: setStoreRoomCode, setCurrentWordPair, clearPlayers } = useGameStore();

  // 启用分享功能（仅在微信小程序环境）
  useEffect(() => {
    if (Taro.getEnv() === Taro.ENV_TYPE.WEAPP) {
      Taro.showShareMenu({
        withShareTicket: true
      });
    }
  }, []);

  // 分享配置
  const onShareAppMessage = () => {
    return {
      title: "Who's the Spy? - English Edition",
      path: '/pages/index/index',
      imageUrl: '', // 可以添加分享图片
      desc: '快来加入我的房间，一起玩英语版谁是卧底！'
    };
  };

  const onShareTimeline = () => {
    return {
      title: "Who's the Spy? - English Edition",
      query: '',
      imageUrl: ''
    };
  };

  const handleStartGame = () => {
    // 生成房间号
    const roomCode = generateRoomCode();
    setRoomCode(roomCode);

    // 跳转到加入页面
    Taro.navigateTo({
      url: '/pages/join/index'
    });
  };

  return (
    <View className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
      {/* 扫描线效果背景 */}
      <View 
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(34, 211, 238, 0.03) 2px, rgba(34, 211, 238, 0.03) 4px)'
        }}
      />
      
      {/* 系统状态 */}
      <View className="absolute top-12 left-6">
        <Text className="text-xs text-neon-cyan tracking-widest">SYSTEM.INIT</Text>
      </View>

      {/* 主标题区域 */}
      <View className="flex-1 flex flex-col items-center justify-center w-full">
        {/* Logo/图标 - JOJO风格间谍 */}
        <View
          className="w-28 h-28 mb-8 rounded-2xl flex items-center justify-center overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, #22d3ee 0%, #a855f7 100%)',
            boxShadow: '0 0 30px rgba(34, 211, 238, 0.4)'
          }}
        >
          <Image
            src="https://g.cdn.meoo.host/agent-generated-images/q4gno1xecrv5/675b.png?auth_key=49c5a1b545f08a5bb3d43256aa01576455aefc59f9348b7303c2a7620f8f0958"
            className="w-24 h-24"
            mode="aspectFit"
          />
        </View>

        {/* 主标题 */}
        <Text 
          className="text-4xl font-bold text-white text-center mb-2"
          style={{ textShadow: '0 0 20px rgba(34, 211, 238, 0.8)' }}
        >
          WHO&apos;S THE
        </Text>
        <Text 
          className="text-3xl font-bold text-center mb-6"
          style={{ 
            color: '#e879f9',
            textShadow: '0 0 20px rgba(232, 121, 249, 0.8)'
          }}
        >
          SPY?
        </Text>
        
        {/* 副标题 */}
        <Text className="text-sm text-muted-foreground text-center mb-12">
          谁是卧底 — English Edition
        </Text>

        {/* 开始按钮 */}
        <View
          className="w-full py-4 rounded-lg flex items-center justify-center mb-4 cursor-pointer"
          style={{
            background: '#22d3ee',
            boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
          }}
          onClick={handleStartGame}
        >
          <Text className="text-black font-bold text-lg uppercase tracking-wider">
            START GAME
          </Text>
        </View>

        {/* 游戏规则按钮 */}
        <View
          className="w-full py-4 rounded-lg flex items-center justify-center border border-solid"
          style={{
            borderColor: 'rgba(232, 121, 249, 0.3)',
            background: 'transparent'
          }}
        >
          <Text className="text-fuchsia-400 font-bold text-sm uppercase tracking-wider">
            HOW TO PLAY
          </Text>
        </View>
      </View>

      {/* 底部版本信息 */}
      <View className="pb-8">
        <Text className="text-xs text-muted-foreground text-center">
          v1.0.0 // CYBERPUNK EDITION
        </Text>
      </View>
    </View>
  );
}
