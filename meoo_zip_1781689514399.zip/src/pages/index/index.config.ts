export default definePageConfig({
  navigationBarTitleText: "Who's the Spy? ",
  navigationBarBackgroundColor: '#0a0a0f',
  navigationBarTextStyle: 'white'
});
