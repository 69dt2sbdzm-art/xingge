import { useEffect, useState } from 'react';
import { View, Text } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useGameStore, getRandomWordPair, Player, Role } from '@/store/game-store';

// 玩家头像组件 - 不显示角色信息，保持神秘
const PlayerAvatar = ({ player, index }: { player: Player; index: number }) => {
  const colors = [
    'from-cyan-400 to-blue-500',
    'from-fuchsia-500 to-purple-600',
    'from-lime-400 to-green-500',
    'from-amber-400 to-orange-500',
    'from-rose-400 to-pink-500',
    'from-violet-400 to-indigo-500',
  ];
  const colorClass = colors[index % colors.length];

  return (
    <View
      className="flex items-center gap-3 p-4 rounded-lg mb-3"
      style={{
        background: '#111118',
        border: '1px solid rgba(34, 211, 238, 0.2)'
      }}
    >
      {/* 头像 */}
      <View
        className="w-10 h-10 rounded-lg flex items-center justify-center"
        style={{
          background: `linear-gradient(135deg, ${colorClass.includes('cyan') ? '#22d3ee' : colorClass.includes('fuchsia') ? '#e879f9' : colorClass.includes('lime') ? '#a3e635' : colorClass.includes('amber') ? '#fbbf24' : colorClass.includes('rose') ? '#fb7185' : '#8b5cf6'} 0%, ${colorClass.includes('cyan') ? '#3b82f6' : colorClass.includes('fuchsia') ? '#9333ea' : colorClass.includes('lime') ? '#22c55e' : colorClass.includes('amber') ? '#f97316' : colorClass.includes('rose') ? '#ec4899' : '#6366f1'} 100%)`
        }}
      >
        <Text className="text-black font-bold text-lg">
          {player.nickname.charAt(0).toUpperCase()}
        </Text>
      </View>

      {/* 玩家信息 - 只显示昵称，不显示角色 */}
      <View className="flex-1">
        <Text className="text-white font-bold">{player.nickname}</Text>
        <Text className="text-xs text-gray-500">READY</Text>
      </View>

      {/* 在线状态 */}
      <View className="flex items-center gap-1">
        <View
          className="w-2 h-2 rounded-full"
          style={{ background: '#a3e635' }}
        />
        <Text className="text-xs" style={{ color: '#a3e635' }}>ONLINE</Text>
      </View>
    </View>
  );
};

export default function RoomPage() {
  const {
    players,
    roomCode,
    currentPlayer,
    isGameStarted,
    startGame,
    assignRoles,
    setCurrentWordPair,
    currentWordPair,
    gamePhase,
    restartGame,
    usedWordPairs
  } = useGameStore();

  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  const isJudge = currentPlayer?.role === 'judge' || currentPlayer?.id === '1';

  const handleStartGame = () => {
    if (players.length < 3) {
      Taro.showToast({
        title: 'At least 3 players needed',
        icon: 'none'
      });
      return;
    }

    // 选择词语
    const wordPair = getRandomWordPair(difficulty);
    setCurrentWordPair(wordPair);

    // 分配角色
    assignRoles();

    // 开始游戏
    startGame();

    // 跳转到词语页面
    Taro.navigateTo({
      url: '/pages/word/index'
    });
  };

  const handleGoToVote = () => {
    Taro.navigateTo({
      url: '/pages/vote/index'
    });
  };

  const handleBack = () => {
    Taro.navigateBack();
  };

  // 法官：开始下一局
  const handleNewGame = () => {
    restartGame();
    Taro.navigateTo({ url: '/pages/word/index' });
  };

  return (
    <View className="min-h-screen bg-background flex flex-col px-6 py-8">
      {/* 扫描线效果背景 */}
      <View
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(34, 211, 238, 0.03) 2px, rgba(34, 211, 238, 0.03) 4px)'
        }}
      />

      {/* 顶部信息栏 */}
      <View className="flex justify-between items-center mb-6">
        <View>
          <Text className="text-xs text-neon-cyan tracking-widest">
            GAME.ROOM // {players.length} PLAYERS
          </Text>
        </View>
        <View>
          <Text className="text-xs" style={{ color: '#a3e635' }}>WAITING...</Text>
        </View>
      </View>

      {/* 房间号 */}
      <View className="mb-6">
        <Text className="text-sm text-muted-foreground mb-2">ROOM CODE</Text>
        <View
          className="py-3 px-4 rounded-lg border border-solid flex items-center justify-between"
          style={{
            background: '#111118',
            borderColor: 'rgba(34, 211, 238, 0.2)'
          }}
        >
          <Text
            className="text-xl font-bold tracking-widest"
            style={{ color: '#22d3ee' }}
          >
            #{roomCode}
          </Text>
          <View
            className="px-3 py-1 rounded"
            style={{ background: 'rgba(34, 211, 238, 0.1)' }}
          >
            <Text className="text-xs" style={{ color: '#22d3ee' }}>COPY</Text>
          </View>
        </View>
      </View>

      {/* 难度选择 */}
      <View className="mb-6">
        <Text className="text-sm text-muted-foreground mb-2">DIFFICULTY</Text>
        <View className="flex gap-2">
          {(['easy', 'medium', 'hard'] as const).map((level) => (
            <View
              key={level}
              className="flex-1 py-2 rounded-lg flex items-center justify-center cursor-pointer"
              style={{
                background: difficulty === level ? '#22d3ee' : '#111118',
                border: `1px solid ${difficulty === level ? '#22d3ee' : 'rgba(34, 211, 238, 0.2)'}`
              }}
              onClick={() => setDifficulty(level)}
            >
              <Text
                className="text-xs font-bold uppercase"
                style={{ color: difficulty === level ? '#000' : '#a1a1aa' }}
              >
                {level}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* 玩家列表 */}
      <View className="flex-1">
        <Text className="text-sm text-muted-foreground mb-2">PLAYERS</Text>
        <View className="space-y-0">
          {players.map((player, index) => (
            <PlayerAvatar key={player.id} player={player} index={index} />
          ))}

          {/* 空位提示 */}
          {players.length < 4 && (
            <View
              className="flex items-center gap-3 p-4 rounded-lg opacity-50"
              style={{
                background: '#111118',
                border: '1px solid rgba(34, 211, 238, 0.1)'
              }}
            >
              <View
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ background: '#374151' }}
              >
                <Text className="text-gray-400 font-bold text-lg">?</Text>
              </View>
              <View className="flex-1">
                <Text className="text-gray-400 font-bold">Waiting...</Text>
                <Text className="text-xs text-gray-600">EMPTY SLOT</Text>
              </View>
            </View>
          )}
        </View>
      </View>

      {/* 底部按钮 */}
      <View className="mt-6">
        {!isGameStarted ? (
          <View
            className="w-full py-4 rounded-lg flex items-center justify-center mb-4 cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%)',
              boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
            }}
            onClick={handleStartGame}
          >
            <Text className="text-black font-bold text-lg uppercase tracking-wider">
              START GAME
            </Text>
          </View>
        ) : (
          <View
            className="w-full py-4 rounded-lg flex items-center justify-center mb-4 cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%)',
              boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
            }}
            onClick={handleGoToVote}
          >
            <Text className="text-black font-bold text-lg uppercase tracking-wider">
              GO TO VOTE
            </Text>
          </View>
        )}

        {/* 法官专属：下一局按钮 */}
        {isJudge && isGameStarted && (
          <View
            className="w-full py-4 rounded-lg flex items-center justify-center mb-4 cursor-pointer border border-solid"
            style={{
              borderColor: 'rgba(232, 121, 249, 0.5)',
              background: 'rgba(232, 121, 249, 0.1)'
            }}
            onClick={handleNewGame}
          >
            <Text className="text-fuchsia-400 font-bold text-lg uppercase tracking-wider">
              NEW GAME (JUDGE)
            </Text>
          </View>
        )}

        <View
          className="w-full py-4 rounded-lg flex items-center justify-center border border-solid cursor-pointer"
          style={{
            borderColor: 'rgba(34, 211, 238, 0.3)',
            background: 'transparent'
          }}
          onClick={handleBack}
        >
          <Text className="text-cyan-400 font-bold text-sm uppercase tracking-wider">
            BACK
          </Text>
        </View>
      </View>
    </View>
  );
}
