export default definePageConfig({
  navigationBarTitleText: '游戏房间',
  navigationBarBackgroundColor: '#0a0a0f',
  navigationBarTextStyle: 'white'
});
