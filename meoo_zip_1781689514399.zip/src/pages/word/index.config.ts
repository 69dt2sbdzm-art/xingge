export default definePageConfig({
  navigationBarTitleText: '你的词语',
  navigationBarBackgroundColor: '#0a0a0f',
  navigationBarTextStyle: 'white'
});
