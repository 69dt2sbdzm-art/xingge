import { useEffect, useState } from 'react';
import { View, Text } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useGameStore, Role } from '@/store/game-store';

// 角色配置
const roleConfig: Record<Role, { label: string; color: string; bgColor: string }> = {
  judge: {
    label: 'JUDGE',
    color: '#22d3ee',
    bgColor: 'rgba(34, 211, 238, 0.1)'
  },
  civilian: {
    label: 'CIVILIAN',
    color: '#a855f7',
    bgColor: 'rgba(168, 85, 247, 0.1)'
  },
  spy: {
    label: 'SPY',
    color: '#e879f9',
    bgColor: 'rgba(232, 121, 249, 0.1)'
  }
};

export default function WordPage() {
  const { currentPlayer, currentWordPair, players } = useGameStore();
  const [showWord, setShowWord] = useState(true);
  const [countdown, setCountdown] = useState(10);

  const role = currentPlayer?.role || 'civilian';
  const word = currentPlayer?.word || '';
  const roleInfo = roleConfig[role];
  const isJudge = role === 'judge';

  // 倒计时自动隐藏
  useEffect(() => {
    if (countdown > 0 && showWord) {
      const timer = setTimeout(() => setCountdown(c => c - 1), 1000);
      return () => clearTimeout(timer);
    } else if (countdown === 0) {
      setShowWord(false);
    }
  }, [countdown, showWord]);

  const handleToggleWord = () => {
    setShowWord(!showWord);
  };

  const handleReady = () => {
    Taro.showToast({
      title: 'Ready!',
      icon: 'success'
    });
    setTimeout(() => {
      Taro.navigateBack();
    }, 1000);
  };

  return (
    <View className="min-h-screen bg-background flex flex-col px-6 py-8">
      {/* 扫描线效果背景 */}
      <View 
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(34, 211, 238, 0.03) 2px, rgba(34, 211, 238, 0.03) 4px)'
        }}
      />

      {/* 页面标题 */}
      <View className="mb-4">
        <Text className="text-xs text-neon-cyan tracking-widest">ROLE.ASSIGNED</Text>
      </View>

      {/* 主要内容区域 */}
      <View className="flex-1 flex flex-col items-center justify-center">
        {/* 角色标识 - 法官显示特殊标识 */}
        <View className="text-center mb-8">
          <Text className="text-sm text-muted-foreground mb-2">YOUR ROLE</Text>
          {isJudge ? (
            <>
              <View
                className="px-6 py-3 rounded-full mb-2"
                style={{ background: 'rgba(34, 211, 238, 0.2)', border: '2px solid #22d3ee' }}
              >
                <Text
                  className="text-xl font-bold"
                  style={{ color: '#22d3ee' }}
                >
                  JUDGE
                </Text>
              </View>
              <Text className="text-xs" style={{ color: '#22d3ee' }}>YOU CONTROL THE GAME</Text>
            </>
          ) : (
            <>
              <View
                className="px-4 py-2 rounded-full mb-2"
                style={{ background: 'rgba(255, 255, 255, 0.1)' }}
              >
                <Text
                  className="text-lg font-bold"
                  style={{ color: '#9ca3af' }}
                >
                  ???
                </Text>
              </View>
              <Text className="text-xs text-gray-500">UNKNOWN</Text>
            </>
          )}
        </View>

        {/* 词语卡片 - 法官显示两个词 */}
        {isJudge ? (
          <View
            className="w-full rounded-2xl p-6 text-center mb-8"
            style={{
              background: '#111118',
              border: '2px solid rgba(34, 211, 238, 0.5)',
              boxShadow: '0 0 30px rgba(34, 211, 238, 0.3)'
            }}
          >
            <Text className="text-xs text-cyan-400 mb-4 uppercase tracking-wider">
              BOTH WORDS
            </Text>
            <View className="flex flex-col gap-4">
              <View
                className="p-4 rounded-xl"
                style={{ background: 'rgba(168, 85, 247, 0.1)', border: '1px solid rgba(168, 85, 247, 0.3)' }}
              >
                <Text className="text-xs text-purple-400 mb-1">CIVILIAN WORD</Text>
                <Text className="text-2xl font-bold text-white">
                  {currentWordPair?.civilian}
                </Text>
              </View>
              <View
                className="p-4 rounded-xl"
                style={{ background: 'rgba(232, 121, 249, 0.1)', border: '1px solid rgba(232, 121, 249, 0.3)' }}
              >
                <Text className="text-xs text-fuchsia-400 mb-1">SPY WORD</Text>
                <Text className="text-2xl font-bold text-white">
                  {currentWordPair?.spy}
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View
            className="w-full rounded-2xl p-8 text-center mb-8 cursor-pointer"
            style={{
              background: '#111118',
              border: '2px solid rgba(34, 211, 238, 0.5)',
              boxShadow: showWord ? '0 0 30px rgba(34, 211, 238, 0.3)' : 'none'
            }}
            onClick={handleToggleWord}
          >
            {showWord ? (
              <>
                <Text className="text-xs text-gray-500 mb-4 uppercase tracking-wider">
                  YOUR WORD
                </Text>
                <Text
                  className="text-4xl font-bold text-white mb-2"
                  style={{ textShadow: '0 0 20px rgba(255,255,255,0.3)' }}
                >
                  {word}
                </Text>
              </>
            ) : (
              <View className="py-8">
                <Text className="text-2xl text-gray-500">[ HIDDEN ]</Text>
                <Text className="text-xs text-gray-600 mt-2">TAP TO SHOW</Text>
              </View>
            )}
          </View>
        )}

        {/* 倒计时提示 */}
        {showWord && countdown > 0 && (
          <View className="mb-4">
            <Text className="text-xs text-gray-500">
              AUTO HIDE: {countdown}s
            </Text>
          </View>
        )}

        {/* 提示信息 */}
        <View className="text-center mb-8">
          {isJudge ? (
            <>
              <Text className="text-xs mb-2" style={{ color: '#22d3ee' }}>
                You are the JUDGE. You know both words.
              </Text>
              <Text className="text-xs text-gray-500">
                Guide the game and start voting when ready.
              </Text>
            </>
          ) : (
            <>
              <Text className="text-xs text-gray-500 mb-2">
                Listen to others and figure out your role!
              </Text>
              <Text className="text-xs" style={{ color: 'rgba(34, 211, 238, 0.5)' }}>
                [ TAP CARD TO HIDE ]
              </Text>
            </>
          )}
        </View>

        {/* 游戏规则提示 - 法官显示不同提示 */}
        {isJudge ? (
          <View
            className="w-full rounded-xl p-4"
            style={{
              background: '#111118',
              border: '1px solid rgba(34, 211, 238, 0.3)'
            }}
          >
            <Text className="text-sm font-bold text-cyan-400 mb-2">JUDGE DUTIES</Text>
            <Text className="text-xs text-gray-500 leading-relaxed">
              • Monitor player descriptions{'\n'}
              • Start voting when round ends{'\n'}
              • Reveal eliminated player&apos;s role{'\n'}
              • Declare winner when game ends
            </Text>
          </View>
        ) : (
          <View
            className="w-full rounded-xl p-4"
            style={{
              background: '#111118',
              border: '1px solid rgba(34, 211, 238, 0.1)'
            }}
          >
            <Text className="text-sm font-bold text-white mb-2">GAME TIPS</Text>
            <Text className="text-xs text-gray-500 leading-relaxed">
              • Describe your word in English{'\n'}
              • Listen to others carefully{'\n'}
              • Figure out if you are civilian or spy{'\n'}
              • Find the spy!
            </Text>
          </View>
        )}

        {/* 法官专属：所有人词语和角色信息 */}
        {isJudge && (
          <View
            className="w-full rounded-xl p-4 mt-4"
            style={{
              background: '#111118',
              border: '1px solid rgba(34, 211, 238, 0.3)'
            }}
          >
            <Text className="text-sm font-bold text-cyan-400 mb-3">JUDGE VIEW // ALL PLAYERS</Text>
            {players.map((player, index) => (
              <View key={player.id} className="flex items-center justify-between py-2 border-b border-gray-800 last:border-0">
                <View className="flex items-center gap-2">
                  <Text className="text-white font-bold">{player.nickname}</Text>
                  <View
                    className="px-2 py-1 rounded text-xs"
                    style={{
                      background: player.role === 'spy' ? 'rgba(232, 121, 249, 0.2)' : player.role === 'judge' ? 'rgba(34, 211, 238, 0.2)' : 'rgba(168, 85, 247, 0.2)',
                      color: player.role === 'spy' ? '#e879f9' : player.role === 'judge' ? '#22d3ee' : '#a855f7'
                    }}
                  >
                    {player.role === 'spy' ? 'SPY' : player.role === 'judge' ? 'JUDGE' : 'CIVILIAN'}
                  </View>
                </View>
                <Text className="text-cyan-400 font-bold">{player.word}</Text>
              </View>
            ))}
            <View className="mt-3 pt-3 border-t border-gray-800">
              <Text className="text-xs text-gray-500">CIVILIAN WORD: {currentWordPair?.civilian}</Text>
              <Text className="text-xs text-gray-500">SPY WORD: {currentWordPair?.spy}</Text>
            </View>
          </View>
        )}
      </View>

      {/* 底部按钮 */}
      <View className="mt-6">
        <View 
          className="w-full py-4 rounded-lg flex items-center justify-center border border-solid cursor-pointer"
          style={{
            borderColor: 'rgba(34, 211, 238, 0.3)',
            background: 'transparent'
          }}
          onClick={handleReady}
        >
          <Text className="text-cyan-400 font-bold text-sm uppercase tracking-wider">
            READY
          </Text>
        </View>
      </View>
    </View>
  );
}
