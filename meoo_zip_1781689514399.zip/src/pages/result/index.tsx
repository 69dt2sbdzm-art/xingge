import { View, Text } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useGameStore } from '@/store/game-store';

export default function ResultPage() {
  const {
    players,
    votes,
    eliminatedPlayers,
    winner,
    currentWordPair,
    nextRound,
    resetGame,
    restartGame,
    currentRound,
    currentPlayer
  } = useGameStore();

  // 获取最新被淘汰的玩家
  const lastEliminatedId = eliminatedPlayers[eliminatedPlayers.length - 1];
  const eliminatedPlayer = players.find(p => p.id === lastEliminatedId);

  // 统计票数
  const voteCount: Record<string, number> = {};
  votes.forEach(vote => {
    voteCount[vote.targetId] = (voteCount[vote.targetId] || 0) + 1;
  });

  const handleNextRound = () => {
    nextRound();
    Taro.navigateBack({ delta: 2 });
  };

  const handleEndGame = () => {
    resetGame();
    Taro.navigateTo({ url: '/pages/index/index' });
  };

  const handleNewGame = () => {
    restartGame();
    // 跳转到词语页面，让所有人看到新角色
    Taro.navigateTo({ url: '/pages/word/index' });
  };

  const isGameOver = winner !== null || eliminatedPlayer?.role === 'spy';

  return (
    <View className="min-h-screen bg-background flex flex-col px-6 py-8">
      {/* 标题 */}
      <View className="mb-8 text-center">
        <Text className="text-xs text-neon-cyan tracking-widest">VOTING RESULT</Text>
        <Text className="text-3xl font-bold text-white mt-2">
          {isGameOver ? 'GAME OVER' : `ROUND ${currentRound} RESULT`}
        </Text>
      </View>

      {/* 被淘汰玩家信息 */}
      {eliminatedPlayer && (
        <View 
          className="rounded-2xl p-6 mb-6 text-center"
          style={{
            background: eliminatedPlayer.role === 'spy' 
              ? 'linear-gradient(135deg, rgba(34, 211, 238, 0.2) 0%, rgba(59, 130, 246, 0.2) 100%)'
              : 'linear-gradient(135deg, rgba(232, 121, 249, 0.2) 0%, rgba(168, 85, 247, 0.2) 100%)',
            border: `2px solid ${eliminatedPlayer.role === 'spy' ? '#22d3ee' : '#e879f9'}`
          }}
        >
          <Text className="text-gray-400 text-sm mb-2">ELIMINATED</Text>
          <Text className="text-3xl font-bold text-white mb-2">{eliminatedPlayer.nickname}</Text>
          <View 
            className="px-4 py-2 rounded-full inline-block"
            style={{ 
              background: eliminatedPlayer.role === 'spy' ? 'rgba(34, 211, 238, 0.2)' : 'rgba(232, 121, 249, 0.2)'
            }}
          >
            <Text 
              className="font-bold"
              style={{ color: eliminatedPlayer.role === 'spy' ? '#22d3ee' : '#e879f9' }}
            >
              {eliminatedPlayer.role === 'spy' ? 'SPY' : 'CIVILIAN'}
            </Text>
          </View>
          <Text className="text-gray-400 text-sm mt-2">
            Word: {eliminatedPlayer.word}
          </Text>
        </View>
      )}

      {/* 投票统计 */}
      <View className="flex-1">
        <Text className="text-sm text-gray-400 mb-4">VOTING BREAKDOWN</Text>
        {players
          .filter(p => !eliminatedPlayers.includes(p.id) && p.role !== 'judge')
          .map((player) => (
            <View 
              key={player.id}
              className="flex items-center justify-between p-4 rounded-lg mb-3"
              style={{ 
                background: player.id === lastEliminatedId ? 'rgba(232, 121, 249, 0.1)' : '#111118',
                border: `1px solid ${player.id === lastEliminatedId ? '#e879f9' : 'rgba(34, 211, 238, 0.2)'}`
              }}
            >
              <View className="flex items-center gap-3">
                <Text className="text-white font-bold">{player.nickname}</Text>
                {player.id === lastEliminatedId && (
                  <Text className="text-xs" style={{ color: '#e879f9' }}>ELIMINATED</Text>
                )}
              </View>
              <Text className="text-cyan-400 font-bold">{voteCount[player.id] || 0} votes</Text>
            </View>
          ))}
      </View>

      {/* 游戏结果 */}
      {isGameOver && (
        <View 
          className="rounded-xl p-6 mb-6 text-center"
          style={{ 
            background: 'rgba(34, 211, 238, 0.1)',
            border: '2px solid #22d3ee'
          }}
        >
          <Text className="text-2xl font-bold mb-2" style={{ color: '#22d3ee' }}>
            {eliminatedPlayer?.role === 'spy' ? 'CIVILIANS WIN!' : 'SPY WINS!'}
          </Text>
          <Text className="text-gray-400 text-sm">
            {eliminatedPlayer?.role === 'spy' 
              ? 'The spy was caught! Civilians win the game.' 
              : 'The spy survived! Spy wins the game.'}
          </Text>
          {currentWordPair && (
            <View className="mt-4 pt-4 border-t border-gray-700">
              <Text className="text-xs text-gray-500">CIVILIAN WORD: {currentWordPair.civilian}</Text>
              <Text className="text-xs text-gray-500">SPY WORD: {currentWordPair.spy}</Text>
            </View>
          )}
        </View>
      )}

      {/* 底部按钮 */}
      <View className="mt-6 space-y-3">
        {isGameOver ? (
          <>
            {/* 再来一局 - 保留玩家重新分配角色 */}
            <View
              className="w-full py-4 rounded-lg flex items-center justify-center cursor-pointer"
              style={{
                background: 'linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%)',
                boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
              }}
              onClick={handleNewGame}
            >
              <Text className="text-black font-bold text-lg">NEW GAME</Text>
            </View>
            {/* 返回首页 */}
            <View
              className="w-full py-4 rounded-lg flex items-center justify-center cursor-pointer border border-solid"
              style={{
                borderColor: 'rgba(34, 211, 238, 0.3)',
                background: 'transparent'
              }}
              onClick={handleEndGame}
            >
              <Text className="text-cyan-400 font-bold text-lg">BACK TO HOME</Text>
            </View>
          </>
        ) : (
          <View
            className="w-full py-4 rounded-lg flex items-center justify-center cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%)',
              boxShadow: '0 0 20px rgba(34, 211, 238, 0.4)'
            }}
            onClick={handleNextRound}
          >
            <Text className="text-black font-bold text-lg">NEXT ROUND</Text>
          </View>
        )}
      </View>
    </View>
  );
}
