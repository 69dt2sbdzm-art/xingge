export default definePageConfig({
  navigationBarTitleText: 'Result',
  navigationStyle: 'custom',
});
