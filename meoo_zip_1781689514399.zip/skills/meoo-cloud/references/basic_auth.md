# 基础密码认证 SOP

只在 `authentication.md` 明确命中 `authImplementationSop=basic_auth`，或小程序场景直接路由到本文件时读取。本文件承接用户名/手机号作为用户名 + 密码，以及小程序微信一键登录 + 账号密码登录。

不要用本文件实现邮箱验证码、短信验证码、注册验证码、登录二次校验、忘记密码、找回密码、重置密码或修改手机号。只要出现这些需求，回到 `authentication.md` 路由并读取 `meoo-cloud-auth` 对应子文档。

## 认证方法

### 普通账密登录（默认方式）

Web/H5 基础密码认证默认采用用户名登录，自动生成 `{username}@meoo.local` 虚拟邮箱以兼容 Supabase Auth。

### 手机号登录

基础密码认证里的手机号登录只是把手机号当作用户名，不发送短信验证码，同样自动生成 `{username}@meoo.local` 虚拟邮箱 + 密码登录。

### 邮箱登录

仅当用户明确要求真实邮箱 + 密码、且不需要邮箱验证码、邮箱确认、忘记密码或找回密码时，才可用 Supabase 原生邮箱密码登录。只要出现邮箱验证码、邮箱确认或邮箱找回密码，必须回到 `authentication.md` 命中 `auth_email_password`。


### 微信登录

小程序场景默认实现「微信一键登录 + 账号密码登录」双入口。


## 实现要点

### 1. 存储完整会话对象

```typescript
const [session, setSession] = useState<Session | null>(null);
```

### 2. 用户名认证示例

实现用户名或手机号 + 密码登录注册时使用此方式；真实邮箱 + 密码不需要包虚拟邮箱：

```typescript
// 注册
await supabase.auth.signUp({
  email: `${username}@meoo.local`,
  password,
  options: { data: { username } },
});

// 登录
await supabase.auth.signInWithPassword({
  email: `${username}@meoo.local`,
  password,
});
```

内部虚拟邮箱只用于 Supabase Auth 登录，不展示给用户；不要把它写入 `profiles.email`。

### 3. 认证状态监听

```typescript
// 正确：同步状态更新 + 在 effect cleanup 里 unsubscribe
useEffect(() => {
  const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
    setSession(session);
    setUser(session?.user ?? null);

    // 延迟任何 Supabase 调用
    if (session?.user) {
      setTimeout(() => {
        fetchUserProfile(session.user.id);
      }, 0);
    }
  });
  return () => subscription.unsubscribe();
}, []);

// 错误：会导致死锁
supabase.auth.onAuthStateChange(async (event, session) => {
  const profile = await supabase.from('profiles').select(); // 死锁
});
```

## 用户数据表设计




### 用户配置文件表

小程序场景的 `profiles` 同时承接「账号密码登录」和「微信登录」两种来源：`username` 由账密注册写入，`openid`/`unionid` 由微信登录写入。

```sql
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE,
  openid TEXT UNIQUE,
  unionid TEXT UNIQUE,
  nickname TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY users_select_own_profile ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY users_update_own_profile ON public.profiles FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
```

### 自动创建配置文件触发器

```sql
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.raw_user_meta_data ->> 'provider' = 'wechat_miniprogram' THEN
    INSERT INTO public.profiles (id, openid, unionid)
    VALUES (NEW.id, NEW.raw_user_meta_data ->> 'openid', NEW.raw_user_meta_data ->> 'unionid')
    ON CONFLICT (id) DO NOTHING;
  ELSE
    INSERT INTO public.profiles (id, username)
    VALUES (NEW.id, NEW.raw_user_meta_data ->> 'username')
    ON CONFLICT (id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
```

不要忘记 `SECURITY DEFINER`。


## 创建测试用户

```sql
INSERT INTO auth.users (
  instance_id, id, aud, role, email,
  encrypted_password, email_confirmed_at,
  created_at, updated_at,
  confirmation_token, recovery_token,
  email_change_token_new, email_change,
  raw_app_meta_data, raw_user_meta_data,
  is_super_admin
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(), 'authenticated', 'authenticated',
  'testuser@meoo.local',
  crypt('password123', gen_salt('bf')),
  NOW(), NOW(), NOW(),
  '', '', '', '',
  '{"provider":"email","providers":["email"]}'::jsonb,
  '{"username":"testuser"}'::jsonb,
  false
);
```

必需字段：`instance_id`、`::jsonb` 类型转换、空字符串令牌（非 NULL）。


---

## 微信小程序登录

### 实现流程

模板预置：

- `functions/wx-mp-login/index.ts` + `src/supabase/wx-mp-login.ts`（封装好的 `wxMpLogin()` / `WxMpConfigMissingError`）
- `src/api/auth.ts`、`src/store/auth-store.ts`（含 `signInWithWeapp` / `signInWithUsername` / `signUpWithUsername` 等 action，用户名内部自动包 `{username}@meoo.local`）
- `src/pages/login/index.tsx`：微信一键登录 + 账号密码 + 注册切换的双入口登录页

按顺序：

1. 部署云函数（必须 `-j false`，登录前没 token）：
   ```bash
   meoo-cli cloud deploy-function -n wx-mp-login -j false
   ```
2. 建 `profiles` 表。
3. 启用模板登录链路：`src/app.config.ts` 加 `pages/login/index`。`auth-store` 模块加载即自动订阅 supabase，无需在 `app.tsx` 触发 init。登录页文案、布局可改，鉴权骨架不要重写。
4. 总结提醒：消息末尾单独成段提醒用户去「云服务 → 登录认证 → 微信登录」配密钥。

### 环境变量（用户手动到「云服务 → 登录认证 → 微信登录」配）

| 变量 | 来源 |
|---|---|
| `WX_APP_ID` | 微信小程序后台 |
| `WX_APP_SECRET` | 微信小程序后台 |

### 登录 UI

「我的」Tab + 模板 `pages/login/index` 两个页面。登录入口收口在「我的」，不要散落在首页。「我的」Tab 未登录展示登录入口（`redirectToLogin`），已登录展示头像、昵称、登出。

展示用户身份：昵称兜底 `nickname || username || '微信用户'`，头像为空给本地兜底图。禁止展示 `email`（`{username}@meoo.local/wx.local` 占位符）和 `openid` / `user.id`（内部标识）。

### 完善头像昵称（可选，默认不用实现）

如果要求获取头像昵称，必须遵守 `Taro.getUserProfile()` 的两条硬性平台规则：

1. 必须由用户主动触发：只能在 button/view 等用户事件的同步回调里直接调用。禁止在 `useLoad` / `useDidShow` / `useEffect` / 异步 callback / `setTimeout` 里自动调用。
2. 每次调用都需要用户明确授权：不要紧跟登录流程静默触发。正确做法是在「我的」页面挂一个独立的「完善头像昵称」按钮。

```typescript
import { useAuthStore } from '@/store/auth-store';
import * as profileApi from '@/api/profile';

async function handleSetProfile() {
  const { userInfo } = await Taro.getUserProfile({ desc: '用于完善个人资料' });
  const { user } = useAuthStore.getState();
  if (!user) return;
  try {
    await profileApi.updateProfile(user.id, {
      nickname: userInfo.nickName,
      avatar_url: userInfo.avatarUrl,
    });
    Taro.showToast({ title: '已更新', icon: 'success' });
  } catch (e) {
    Taro.showToast({ title: (e as Error).message, icon: 'none' });
  }
}
```

### 总结里必须出现的提醒文案

实现完微信登录后，回复用户的最终总结的末尾必须单独成段，原文：

> **下一步你要手动做一件事**：到「云服务 → 登录认证 → 微信登录」配置 `WX_APP_ID` 和 `WX_APP_SECRET`。


